gdjs.NewSceneCode = {};
gdjs.NewSceneCode.forEachCount0_5 = 0;

gdjs.NewSceneCode.forEachCount1_5 = 0;

gdjs.NewSceneCode.forEachCount2_5 = 0;

gdjs.NewSceneCode.forEachCount3_5 = 0;

gdjs.NewSceneCode.forEachCount4_5 = 0;

gdjs.NewSceneCode.forEachCount5_5 = 0;

gdjs.NewSceneCode.forEachCount6_5 = 0;

gdjs.NewSceneCode.forEachCount7_5 = 0;

gdjs.NewSceneCode.forEachIndex3 = 0;

gdjs.NewSceneCode.forEachIndex5 = 0;

gdjs.NewSceneCode.forEachObjects3 = [];

gdjs.NewSceneCode.forEachObjects5 = [];

gdjs.NewSceneCode.forEachTemporary3 = null;

gdjs.NewSceneCode.forEachTotalCount3 = 0;

gdjs.NewSceneCode.forEachTotalCount5 = 0;

gdjs.NewSceneCode.GDcard_95crabObjects1= [];
gdjs.NewSceneCode.GDcard_95crabObjects2= [];
gdjs.NewSceneCode.GDcard_95crabObjects3= [];
gdjs.NewSceneCode.GDcard_95crabObjects4= [];
gdjs.NewSceneCode.GDcard_95crabObjects5= [];
gdjs.NewSceneCode.GDcard_95crabObjects6= [];
gdjs.NewSceneCode.GDcard_95crabObjects7= [];
gdjs.NewSceneCode.GDcard_95seahorseObjects1= [];
gdjs.NewSceneCode.GDcard_95seahorseObjects2= [];
gdjs.NewSceneCode.GDcard_95seahorseObjects3= [];
gdjs.NewSceneCode.GDcard_95seahorseObjects4= [];
gdjs.NewSceneCode.GDcard_95seahorseObjects5= [];
gdjs.NewSceneCode.GDcard_95seahorseObjects6= [];
gdjs.NewSceneCode.GDcard_95seahorseObjects7= [];
gdjs.NewSceneCode.GDcard_95snailObjects1= [];
gdjs.NewSceneCode.GDcard_95snailObjects2= [];
gdjs.NewSceneCode.GDcard_95snailObjects3= [];
gdjs.NewSceneCode.GDcard_95snailObjects4= [];
gdjs.NewSceneCode.GDcard_95snailObjects5= [];
gdjs.NewSceneCode.GDcard_95snailObjects6= [];
gdjs.NewSceneCode.GDcard_95snailObjects7= [];
gdjs.NewSceneCode.GDcard_95seagrassObjects1= [];
gdjs.NewSceneCode.GDcard_95seagrassObjects2= [];
gdjs.NewSceneCode.GDcard_95seagrassObjects3= [];
gdjs.NewSceneCode.GDcard_95seagrassObjects4= [];
gdjs.NewSceneCode.GDcard_95seagrassObjects5= [];
gdjs.NewSceneCode.GDcard_95seagrassObjects6= [];
gdjs.NewSceneCode.GDcard_95seagrassObjects7= [];
gdjs.NewSceneCode.GDcard_95coralObjects1= [];
gdjs.NewSceneCode.GDcard_95coralObjects2= [];
gdjs.NewSceneCode.GDcard_95coralObjects3= [];
gdjs.NewSceneCode.GDcard_95coralObjects4= [];
gdjs.NewSceneCode.GDcard_95coralObjects5= [];
gdjs.NewSceneCode.GDcard_95coralObjects6= [];
gdjs.NewSceneCode.GDcard_95coralObjects7= [];
gdjs.NewSceneCode.GDcard_95anemoneObjects1= [];
gdjs.NewSceneCode.GDcard_95anemoneObjects2= [];
gdjs.NewSceneCode.GDcard_95anemoneObjects3= [];
gdjs.NewSceneCode.GDcard_95anemoneObjects4= [];
gdjs.NewSceneCode.GDcard_95anemoneObjects5= [];
gdjs.NewSceneCode.GDcard_95anemoneObjects6= [];
gdjs.NewSceneCode.GDcard_95anemoneObjects7= [];
gdjs.NewSceneCode.GDcard_95plasticbagObjects1= [];
gdjs.NewSceneCode.GDcard_95plasticbagObjects2= [];
gdjs.NewSceneCode.GDcard_95plasticbagObjects3= [];
gdjs.NewSceneCode.GDcard_95plasticbagObjects4= [];
gdjs.NewSceneCode.GDcard_95plasticbagObjects5= [];
gdjs.NewSceneCode.GDcard_95plasticbagObjects6= [];
gdjs.NewSceneCode.GDcard_95plasticbagObjects7= [];
gdjs.NewSceneCode.GDcard_95blowfishObjects1= [];
gdjs.NewSceneCode.GDcard_95blowfishObjects2= [];
gdjs.NewSceneCode.GDcard_95blowfishObjects3= [];
gdjs.NewSceneCode.GDcard_95blowfishObjects4= [];
gdjs.NewSceneCode.GDcard_95blowfishObjects5= [];
gdjs.NewSceneCode.GDcard_95blowfishObjects6= [];
gdjs.NewSceneCode.GDcard_95blowfishObjects7= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects1= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects2= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects3= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects4= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects5= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects6= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects7= [];
gdjs.NewSceneCode.GDnewgame_95buttonObjects1= [];
gdjs.NewSceneCode.GDnewgame_95buttonObjects2= [];
gdjs.NewSceneCode.GDnewgame_95buttonObjects3= [];
gdjs.NewSceneCode.GDnewgame_95buttonObjects4= [];
gdjs.NewSceneCode.GDnewgame_95buttonObjects5= [];
gdjs.NewSceneCode.GDnewgame_95buttonObjects6= [];
gdjs.NewSceneCode.GDnewgame_95buttonObjects7= [];
gdjs.NewSceneCode.GDboardObjects1= [];
gdjs.NewSceneCode.GDboardObjects2= [];
gdjs.NewSceneCode.GDboardObjects3= [];
gdjs.NewSceneCode.GDboardObjects4= [];
gdjs.NewSceneCode.GDboardObjects5= [];
gdjs.NewSceneCode.GDboardObjects6= [];
gdjs.NewSceneCode.GDboardObjects7= [];
gdjs.NewSceneCode.GDbackgroundObjects1= [];
gdjs.NewSceneCode.GDbackgroundObjects2= [];
gdjs.NewSceneCode.GDbackgroundObjects3= [];
gdjs.NewSceneCode.GDbackgroundObjects4= [];
gdjs.NewSceneCode.GDbackgroundObjects5= [];
gdjs.NewSceneCode.GDbackgroundObjects6= [];
gdjs.NewSceneCode.GDbackgroundObjects7= [];
gdjs.NewSceneCode.GDpairsObjects1= [];
gdjs.NewSceneCode.GDpairsObjects2= [];
gdjs.NewSceneCode.GDpairsObjects3= [];
gdjs.NewSceneCode.GDpairsObjects4= [];
gdjs.NewSceneCode.GDpairsObjects5= [];
gdjs.NewSceneCode.GDpairsObjects6= [];
gdjs.NewSceneCode.GDpairsObjects7= [];
gdjs.NewSceneCode.GDnewgameObjects1= [];
gdjs.NewSceneCode.GDnewgameObjects2= [];
gdjs.NewSceneCode.GDnewgameObjects3= [];
gdjs.NewSceneCode.GDnewgameObjects4= [];
gdjs.NewSceneCode.GDnewgameObjects5= [];
gdjs.NewSceneCode.GDnewgameObjects6= [];
gdjs.NewSceneCode.GDnewgameObjects7= [];
gdjs.NewSceneCode.GDyouwonObjects1= [];
gdjs.NewSceneCode.GDyouwonObjects2= [];
gdjs.NewSceneCode.GDyouwonObjects3= [];
gdjs.NewSceneCode.GDyouwonObjects4= [];
gdjs.NewSceneCode.GDyouwonObjects5= [];
gdjs.NewSceneCode.GDyouwonObjects6= [];
gdjs.NewSceneCode.GDyouwonObjects7= [];
gdjs.NewSceneCode.GDstar_95particleObjects1= [];
gdjs.NewSceneCode.GDstar_95particleObjects2= [];
gdjs.NewSceneCode.GDstar_95particleObjects3= [];
gdjs.NewSceneCode.GDstar_95particleObjects4= [];
gdjs.NewSceneCode.GDstar_95particleObjects5= [];
gdjs.NewSceneCode.GDstar_95particleObjects6= [];
gdjs.NewSceneCode.GDstar_95particleObjects7= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects1= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects2= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects3= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects4= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects5= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects6= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects7= [];
gdjs.NewSceneCode.GDui_95backgroundObjects1= [];
gdjs.NewSceneCode.GDui_95backgroundObjects2= [];
gdjs.NewSceneCode.GDui_95backgroundObjects3= [];
gdjs.NewSceneCode.GDui_95backgroundObjects4= [];
gdjs.NewSceneCode.GDui_95backgroundObjects5= [];
gdjs.NewSceneCode.GDui_95backgroundObjects6= [];
gdjs.NewSceneCode.GDui_95backgroundObjects7= [];
gdjs.NewSceneCode.GDtitleTextObjects1= [];
gdjs.NewSceneCode.GDtitleTextObjects2= [];
gdjs.NewSceneCode.GDtitleTextObjects3= [];
gdjs.NewSceneCode.GDtitleTextObjects4= [];
gdjs.NewSceneCode.GDtitleTextObjects5= [];
gdjs.NewSceneCode.GDtitleTextObjects6= [];
gdjs.NewSceneCode.GDtitleTextObjects7= [];

gdjs.NewSceneCode.conditionTrue_0 = {val:false};
gdjs.NewSceneCode.condition0IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition1IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition2IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition3IsTrue_0 = {val:false};
gdjs.NewSceneCode.conditionTrue_1 = {val:false};
gdjs.NewSceneCode.condition0IsTrue_1 = {val:false};
gdjs.NewSceneCode.condition1IsTrue_1 = {val:false};
gdjs.NewSceneCode.condition2IsTrue_1 = {val:false};
gdjs.NewSceneCode.condition3IsTrue_1 = {val:false};


gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595blowfishObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595crabObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seahorseObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595snailObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seagrassObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595coralObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595anemoneObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595plasticbagObjects4Objects = Hashtable.newFrom({"card_blowfish": gdjs.NewSceneCode.GDcard_95blowfishObjects4, "card_crab": gdjs.NewSceneCode.GDcard_95crabObjects4, "card_seahorse": gdjs.NewSceneCode.GDcard_95seahorseObjects4, "card_snail": gdjs.NewSceneCode.GDcard_95snailObjects4, "card_seagrass": gdjs.NewSceneCode.GDcard_95seagrassObjects4, "card_coral": gdjs.NewSceneCode.GDcard_95coralObjects4, "card_anemone": gdjs.NewSceneCode.GDcard_95anemoneObjects4, "card_plasticbag": gdjs.NewSceneCode.GDcard_95plasticbagObjects4});gdjs.NewSceneCode.eventsList0x722bfc = function(runtimeScene) {

{

/* Reuse gdjs.NewSceneCode.GDcard_95anemoneObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95blowfishObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95coralObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95crabObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95plasticbagObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seagrassObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seahorseObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95snailObjects4 */

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595blowfishObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595crabObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seahorseObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595snailObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seagrassObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595coralObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595anemoneObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595plasticbagObjects4Objects);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDcard_95anemoneObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95blowfishObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95coralObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95crabObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95plasticbagObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seagrassObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seahorseObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95snailObjects4 */
/* Reuse gdjs.NewSceneCode.GDposition_95placeholderObjects4 */
{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDposition_95placeholderObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDposition_95placeholderObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x722bfc
gdjs.NewSceneCode.eventsList0x7230cc = function(runtimeScene) {

{



}


{

gdjs.NewSceneCode.GDcard_95anemoneObjects4.createFrom(runtimeScene.getObjects("card_anemone"));
gdjs.NewSceneCode.GDcard_95blowfishObjects4.createFrom(runtimeScene.getObjects("card_blowfish"));
gdjs.NewSceneCode.GDcard_95coralObjects4.createFrom(runtimeScene.getObjects("card_coral"));
gdjs.NewSceneCode.GDcard_95crabObjects4.createFrom(runtimeScene.getObjects("card_crab"));
gdjs.NewSceneCode.GDcard_95plasticbagObjects4.createFrom(runtimeScene.getObjects("card_plasticbag"));
gdjs.NewSceneCode.GDcard_95seagrassObjects4.createFrom(runtimeScene.getObjects("card_seagrass"));
gdjs.NewSceneCode.GDcard_95seahorseObjects4.createFrom(runtimeScene.getObjects("card_seahorse"));
gdjs.NewSceneCode.GDcard_95snailObjects4.createFrom(runtimeScene.getObjects("card_snail"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95blowfishObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95blowfishObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95blowfishObjects4[k] = gdjs.NewSceneCode.GDcard_95blowfishObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95blowfishObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95crabObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95crabObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95crabObjects4[k] = gdjs.NewSceneCode.GDcard_95crabObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95crabObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seahorseObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seahorseObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seahorseObjects4[k] = gdjs.NewSceneCode.GDcard_95seahorseObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seahorseObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95snailObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95snailObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95snailObjects4[k] = gdjs.NewSceneCode.GDcard_95snailObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95snailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seagrassObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seagrassObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seagrassObjects4[k] = gdjs.NewSceneCode.GDcard_95seagrassObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seagrassObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95coralObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95coralObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95coralObjects4[k] = gdjs.NewSceneCode.GDcard_95coralObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95coralObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95anemoneObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95anemoneObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95anemoneObjects4[k] = gdjs.NewSceneCode.GDcard_95anemoneObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95anemoneObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95plasticbagObjects4[k] = gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length = k;}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDcard_95anemoneObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95blowfishObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95coralObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95crabObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95plasticbagObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seagrassObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seahorseObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95snailObjects4 */
gdjs.NewSceneCode.GDposition_95placeholderObjects4.createFrom(gdjs.NewSceneCode.GDposition_95placeholderObjects3);

{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x722bfc(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.NewSceneCode.eventsList0x7230cc
gdjs.NewSceneCode.eventsList0x6a3574 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


{

gdjs.NewSceneCode.GDposition_95placeholderObjects2.createFrom(runtimeScene.getObjects("position_placeholder"));

for(gdjs.NewSceneCode.forEachIndex3 = 0;gdjs.NewSceneCode.forEachIndex3 < gdjs.NewSceneCode.GDposition_95placeholderObjects2.length;++gdjs.NewSceneCode.forEachIndex3) {
gdjs.NewSceneCode.GDposition_95placeholderObjects3.length = 0;


gdjs.NewSceneCode.forEachTemporary3 = gdjs.NewSceneCode.GDposition_95placeholderObjects2[gdjs.NewSceneCode.forEachIndex3];
gdjs.NewSceneCode.GDposition_95placeholderObjects3.push(gdjs.NewSceneCode.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.NewSceneCode.eventsList0x7230cc(runtimeScene);} //Subevents end.
}
}

}


{



}


{


{
gdjs.NewSceneCode.GDscreen_95fadeObjects1.createFrom(runtimeScene.getObjects("screen_fade"));
{for(var i = 0, len = gdjs.NewSceneCode.GDscreen_95fadeObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDscreen_95fadeObjects1[i].getBehavior("Tween").addObjectOpacityTween("fade_in", 0, "linear", 1000, true);
}
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6a3574
gdjs.NewSceneCode.eventsList0x6a34dc = function(runtimeScene) {

{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Fade");
}{gdjs.adMob.loadBanner("ca-app-pub-1185478853601542/8994690365", "", true, true, true, false);
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x6a3574(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6a34dc
gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595blowfishObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595crabObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seahorseObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595snailObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seagrassObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595coralObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595anemoneObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595plasticbagObjects2Objects = Hashtable.newFrom({"card_blowfish": gdjs.NewSceneCode.GDcard_95blowfishObjects2, "card_crab": gdjs.NewSceneCode.GDcard_95crabObjects2, "card_seahorse": gdjs.NewSceneCode.GDcard_95seahorseObjects2, "card_snail": gdjs.NewSceneCode.GDcard_95snailObjects2, "card_seagrass": gdjs.NewSceneCode.GDcard_95seagrassObjects2, "card_coral": gdjs.NewSceneCode.GDcard_95coralObjects2, "card_anemone": gdjs.NewSceneCode.GDcard_95anemoneObjects2, "card_plasticbag": gdjs.NewSceneCode.GDcard_95plasticbagObjects2});gdjs.NewSceneCode.eventsList0x6d31ec = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "show_cards");
}{runtimeScene.getVariables().getFromIndex(4).setString("show_cards");
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6d31ec
gdjs.NewSceneCode.eventsList0x6da45c = function(runtimeScene) {

{



}


{


{
gdjs.NewSceneCode.GDcard_95anemoneObjects3.createFrom(gdjs.NewSceneCode.GDcard_95anemoneObjects2);

gdjs.NewSceneCode.GDcard_95blowfishObjects3.createFrom(gdjs.NewSceneCode.GDcard_95blowfishObjects2);

gdjs.NewSceneCode.GDcard_95coralObjects3.createFrom(gdjs.NewSceneCode.GDcard_95coralObjects2);

gdjs.NewSceneCode.GDcard_95crabObjects3.createFrom(gdjs.NewSceneCode.GDcard_95crabObjects2);

gdjs.NewSceneCode.GDcard_95plasticbagObjects3.createFrom(gdjs.NewSceneCode.GDcard_95plasticbagObjects2);

gdjs.NewSceneCode.GDcard_95seagrassObjects3.createFrom(gdjs.NewSceneCode.GDcard_95seagrassObjects2);

gdjs.NewSceneCode.GDcard_95seahorseObjects3.createFrom(gdjs.NewSceneCode.GDcard_95seahorseObjects2);

gdjs.NewSceneCode.GDcard_95snailObjects3.createFrom(gdjs.NewSceneCode.GDcard_95snailObjects2);

{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
}}

}


{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDcard_95anemoneObjects3.createFrom(gdjs.NewSceneCode.GDcard_95anemoneObjects2);

gdjs.NewSceneCode.GDcard_95blowfishObjects3.createFrom(gdjs.NewSceneCode.GDcard_95blowfishObjects2);

gdjs.NewSceneCode.GDcard_95coralObjects3.createFrom(gdjs.NewSceneCode.GDcard_95coralObjects2);

gdjs.NewSceneCode.GDcard_95crabObjects3.createFrom(gdjs.NewSceneCode.GDcard_95crabObjects2);

gdjs.NewSceneCode.GDcard_95plasticbagObjects3.createFrom(gdjs.NewSceneCode.GDcard_95plasticbagObjects2);

gdjs.NewSceneCode.GDcard_95seagrassObjects3.createFrom(gdjs.NewSceneCode.GDcard_95seagrassObjects2);

gdjs.NewSceneCode.GDcard_95seahorseObjects3.createFrom(gdjs.NewSceneCode.GDcard_95seahorseObjects2);

gdjs.NewSceneCode.GDcard_95snailObjects3.createFrom(gdjs.NewSceneCode.GDcard_95snailObjects2);

{runtimeScene.getVariables().getFromIndex(2).setString((gdjs.RuntimeObject.getVariableString(((gdjs.NewSceneCode.GDcard_95plasticbagObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95anemoneObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95coralObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95seagrassObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95snailObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95seahorseObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95crabObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95blowfishObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.NewSceneCode.GDcard_95blowfishObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95crabObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95seahorseObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95snailObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95seagrassObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95coralObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95anemoneObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95plasticbagObjects3[0].getVariables()).get("id"))));
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x6d31ec(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDcard_95anemoneObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95blowfishObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95coralObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95crabObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95plasticbagObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95seagrassObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95seahorseObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95snailObjects2 */
{runtimeScene.getVariables().getFromIndex(0).setString((gdjs.RuntimeObject.getVariableString(((gdjs.NewSceneCode.GDcard_95plasticbagObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95anemoneObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95coralObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95seagrassObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95snailObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95seahorseObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95crabObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95blowfishObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.NewSceneCode.GDcard_95blowfishObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95crabObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95seahorseObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95snailObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95seagrassObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95coralObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95anemoneObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95plasticbagObjects2[0].getVariables()).get("id"))));
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6da45c
gdjs.NewSceneCode.eventsList0x6da774 = function(runtimeScene) {

{



}


{

gdjs.NewSceneCode.GDcard_95anemoneObjects2.createFrom(runtimeScene.getObjects("card_anemone"));
gdjs.NewSceneCode.GDcard_95blowfishObjects2.createFrom(runtimeScene.getObjects("card_blowfish"));
gdjs.NewSceneCode.GDcard_95coralObjects2.createFrom(runtimeScene.getObjects("card_coral"));
gdjs.NewSceneCode.GDcard_95crabObjects2.createFrom(runtimeScene.getObjects("card_crab"));
gdjs.NewSceneCode.GDcard_95plasticbagObjects2.createFrom(runtimeScene.getObjects("card_plasticbag"));
gdjs.NewSceneCode.GDcard_95seagrassObjects2.createFrom(runtimeScene.getObjects("card_seagrass"));
gdjs.NewSceneCode.GDcard_95seahorseObjects2.createFrom(runtimeScene.getObjects("card_seahorse"));
gdjs.NewSceneCode.GDcard_95snailObjects2.createFrom(runtimeScene.getObjects("card_snail"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
gdjs.NewSceneCode.condition2IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595blowfishObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595crabObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seahorseObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595snailObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seagrassObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595coralObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595anemoneObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595plasticbagObjects2Objects, runtimeScene, true, false);
}if ( gdjs.NewSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95blowfishObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95blowfishObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95blowfishObjects2[k] = gdjs.NewSceneCode.GDcard_95blowfishObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95blowfishObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95crabObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95crabObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95crabObjects2[k] = gdjs.NewSceneCode.GDcard_95crabObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95crabObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seahorseObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seahorseObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seahorseObjects2[k] = gdjs.NewSceneCode.GDcard_95seahorseObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seahorseObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95snailObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95snailObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95snailObjects2[k] = gdjs.NewSceneCode.GDcard_95snailObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95snailObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seagrassObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seagrassObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seagrassObjects2[k] = gdjs.NewSceneCode.GDcard_95seagrassObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seagrassObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95coralObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95coralObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95coralObjects2[k] = gdjs.NewSceneCode.GDcard_95coralObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95coralObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95anemoneObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95anemoneObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95anemoneObjects2[k] = gdjs.NewSceneCode.GDcard_95anemoneObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95anemoneObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95plasticbagObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95plasticbagObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95plasticbagObjects2[k] = gdjs.NewSceneCode.GDcard_95plasticbagObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95plasticbagObjects2.length = k;}}
}
if (gdjs.NewSceneCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/cockatrice_playcard.mp3", false, 100, 1);
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x6da45c(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6da774
gdjs.NewSceneCode.eventsList0x6b35bc = function(runtimeScene) {

{


{
/* Reuse gdjs.NewSceneCode.GDcard_95anemoneObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95blowfishObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95coralObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95crabObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95plasticbagObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95seagrassObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95seahorseObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95snailObjects2 */
{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects2[i].setAnimationName("front");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6b35bc
gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595blowfishObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595crabObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seahorseObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595snailObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seagrassObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595coralObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595anemoneObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595plasticbagObjects4Objects = Hashtable.newFrom({"card_blowfish": gdjs.NewSceneCode.GDcard_95blowfishObjects4, "card_crab": gdjs.NewSceneCode.GDcard_95crabObjects4, "card_seahorse": gdjs.NewSceneCode.GDcard_95seahorseObjects4, "card_snail": gdjs.NewSceneCode.GDcard_95snailObjects4, "card_seagrass": gdjs.NewSceneCode.GDcard_95seagrassObjects4, "card_coral": gdjs.NewSceneCode.GDcard_95coralObjects4, "card_anemone": gdjs.NewSceneCode.GDcard_95anemoneObjects4, "card_plasticbag": gdjs.NewSceneCode.GDcard_95plasticbagObjects4});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDstar_9595particleObjects6Objects = Hashtable.newFrom({"star_particle": gdjs.NewSceneCode.GDstar_95particleObjects6});gdjs.NewSceneCode.eventsList0x6b5a6c = function(runtimeScene) {

{


{
gdjs.NewSceneCode.GDcard_95anemoneObjects6.createFrom(gdjs.NewSceneCode.GDcard_95anemoneObjects5);

gdjs.NewSceneCode.GDcard_95blowfishObjects6.createFrom(gdjs.NewSceneCode.GDcard_95blowfishObjects5);

gdjs.NewSceneCode.GDcard_95coralObjects6.createFrom(gdjs.NewSceneCode.GDcard_95coralObjects5);

gdjs.NewSceneCode.GDcard_95crabObjects6.createFrom(gdjs.NewSceneCode.GDcard_95crabObjects5);

gdjs.NewSceneCode.GDcard_95plasticbagObjects6.createFrom(gdjs.NewSceneCode.GDcard_95plasticbagObjects5);

gdjs.NewSceneCode.GDcard_95seagrassObjects6.createFrom(gdjs.NewSceneCode.GDcard_95seagrassObjects5);

gdjs.NewSceneCode.GDcard_95seahorseObjects6.createFrom(gdjs.NewSceneCode.GDcard_95seahorseObjects5);

gdjs.NewSceneCode.GDcard_95snailObjects6.createFrom(gdjs.NewSceneCode.GDcard_95snailObjects5);

gdjs.NewSceneCode.GDstar_95particleObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDstar_9595particleObjects6Objects, (( gdjs.NewSceneCode.GDcard_95plasticbagObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95anemoneObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95coralObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95seagrassObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95snailObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95seahorseObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95crabObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95blowfishObjects6.length === 0 ) ? 0 :gdjs.NewSceneCode.GDcard_95blowfishObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95crabObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95seahorseObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95snailObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95seagrassObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95coralObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95anemoneObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95plasticbagObjects6[0].getPointX("")), (( gdjs.NewSceneCode.GDcard_95plasticbagObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95anemoneObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95coralObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95seagrassObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95snailObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95seahorseObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95crabObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95blowfishObjects6.length === 0 ) ? 0 :gdjs.NewSceneCode.GDcard_95blowfishObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95crabObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95seahorseObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95snailObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95seagrassObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95coralObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95anemoneObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95plasticbagObjects6[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDstar_95particleObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDstar_95particleObjects6[i].setZOrder(100);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/cuckoo.wav", false, 100, 1);
}}

}


{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition0IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7134532);
}
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDcard_95anemoneObjects6.createFrom(gdjs.NewSceneCode.GDcard_95anemoneObjects5);

gdjs.NewSceneCode.GDcard_95blowfishObjects6.createFrom(gdjs.NewSceneCode.GDcard_95blowfishObjects5);

gdjs.NewSceneCode.GDcard_95coralObjects6.createFrom(gdjs.NewSceneCode.GDcard_95coralObjects5);

gdjs.NewSceneCode.GDcard_95crabObjects6.createFrom(gdjs.NewSceneCode.GDcard_95crabObjects5);

gdjs.NewSceneCode.GDcard_95plasticbagObjects6.createFrom(gdjs.NewSceneCode.GDcard_95plasticbagObjects5);

gdjs.NewSceneCode.GDcard_95seagrassObjects6.createFrom(gdjs.NewSceneCode.GDcard_95seagrassObjects5);

gdjs.NewSceneCode.GDcard_95seahorseObjects6.createFrom(gdjs.NewSceneCode.GDcard_95seahorseObjects5);

gdjs.NewSceneCode.GDcard_95snailObjects6.createFrom(gdjs.NewSceneCode.GDcard_95snailObjects5);

{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6b5a6c
gdjs.NewSceneCode.eventsList0x6b58f4 = function(runtimeScene) {

{

/* Reuse gdjs.NewSceneCode.GDcard_95anemoneObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95blowfishObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95coralObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95crabObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95plasticbagObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seagrassObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seahorseObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95snailObjects4 */

gdjs.NewSceneCode.forEachTotalCount5 = 0;
gdjs.NewSceneCode.forEachObjects5.length = 0;
gdjs.NewSceneCode.forEachCount0_5 = gdjs.NewSceneCode.GDcard_95blowfishObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount0_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95blowfishObjects4);
gdjs.NewSceneCode.forEachCount1_5 = gdjs.NewSceneCode.GDcard_95crabObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount1_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95crabObjects4);
gdjs.NewSceneCode.forEachCount2_5 = gdjs.NewSceneCode.GDcard_95seahorseObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount2_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95seahorseObjects4);
gdjs.NewSceneCode.forEachCount3_5 = gdjs.NewSceneCode.GDcard_95snailObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount3_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95snailObjects4);
gdjs.NewSceneCode.forEachCount4_5 = gdjs.NewSceneCode.GDcard_95seagrassObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount4_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95seagrassObjects4);
gdjs.NewSceneCode.forEachCount5_5 = gdjs.NewSceneCode.GDcard_95coralObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount5_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95coralObjects4);
gdjs.NewSceneCode.forEachCount6_5 = gdjs.NewSceneCode.GDcard_95anemoneObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount6_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95anemoneObjects4);
gdjs.NewSceneCode.forEachCount7_5 = gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount7_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95plasticbagObjects4);
for(gdjs.NewSceneCode.forEachIndex5 = 0;gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachTotalCount5;++gdjs.NewSceneCode.forEachIndex5) {
gdjs.NewSceneCode.GDcard_95anemoneObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95blowfishObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95coralObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95crabObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95plasticbagObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95seagrassObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95seahorseObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95snailObjects5.length = 0;


if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5) {
    gdjs.NewSceneCode.GDcard_95crabObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5) {
    gdjs.NewSceneCode.GDcard_95snailObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5+gdjs.NewSceneCode.forEachCount4_5) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5+gdjs.NewSceneCode.forEachCount4_5+gdjs.NewSceneCode.forEachCount5_5) {
    gdjs.NewSceneCode.GDcard_95coralObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5+gdjs.NewSceneCode.forEachCount4_5+gdjs.NewSceneCode.forEachCount5_5+gdjs.NewSceneCode.forEachCount6_5) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5+gdjs.NewSceneCode.forEachCount4_5+gdjs.NewSceneCode.forEachCount5_5+gdjs.NewSceneCode.forEachCount6_5+gdjs.NewSceneCode.forEachCount7_5) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
if (true) {

{ //Subevents: 
gdjs.NewSceneCode.eventsList0x6b5a6c(runtimeScene);} //Subevents end.
}
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6b58f4
gdjs.NewSceneCode.eventsList0x6b57fc = function(runtimeScene) {

{

/* Reuse gdjs.NewSceneCode.GDcard_95anemoneObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95blowfishObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95coralObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95crabObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95plasticbagObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seagrassObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seahorseObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95snailObjects4 */

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95blowfishObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95blowfishObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95blowfishObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95blowfishObjects4[k] = gdjs.NewSceneCode.GDcard_95blowfishObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95blowfishObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95crabObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95crabObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95crabObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95crabObjects4[k] = gdjs.NewSceneCode.GDcard_95crabObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95crabObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seahorseObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seahorseObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95seahorseObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seahorseObjects4[k] = gdjs.NewSceneCode.GDcard_95seahorseObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seahorseObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95snailObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95snailObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95snailObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95snailObjects4[k] = gdjs.NewSceneCode.GDcard_95snailObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95snailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seagrassObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seagrassObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95seagrassObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seagrassObjects4[k] = gdjs.NewSceneCode.GDcard_95seagrassObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seagrassObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95coralObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95coralObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95coralObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95coralObjects4[k] = gdjs.NewSceneCode.GDcard_95coralObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95coralObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95anemoneObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95anemoneObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95anemoneObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95anemoneObjects4[k] = gdjs.NewSceneCode.GDcard_95anemoneObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95anemoneObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95plasticbagObjects4[k] = gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length = k;}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList0x6b58f4(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6b57fc
gdjs.NewSceneCode.eventsList0x6b7a2c = function(runtimeScene) {

{



}


{


{
gdjs.NewSceneCode.GDcard_95anemoneObjects4.createFrom(runtimeScene.getObjects("card_anemone"));
gdjs.NewSceneCode.GDcard_95blowfishObjects4.createFrom(runtimeScene.getObjects("card_blowfish"));
gdjs.NewSceneCode.GDcard_95coralObjects4.createFrom(runtimeScene.getObjects("card_coral"));
gdjs.NewSceneCode.GDcard_95crabObjects4.createFrom(runtimeScene.getObjects("card_crab"));
gdjs.NewSceneCode.GDcard_95plasticbagObjects4.createFrom(runtimeScene.getObjects("card_plasticbag"));
gdjs.NewSceneCode.GDcard_95seagrassObjects4.createFrom(runtimeScene.getObjects("card_seagrass"));
gdjs.NewSceneCode.GDcard_95seahorseObjects4.createFrom(runtimeScene.getObjects("card_seahorse"));
gdjs.NewSceneCode.GDcard_95snailObjects4.createFrom(runtimeScene.getObjects("card_snail"));
{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595blowfishObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595crabObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seahorseObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595snailObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seagrassObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595coralObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595anemoneObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595plasticbagObjects4Objects);
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x6b57fc(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6b7a2c
gdjs.NewSceneCode.eventsList0x6b78ac = function(runtimeScene) {

{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2));
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDpairsObjects4.createFrom(runtimeScene.getObjects("pairs"));
{runtimeScene.getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.NewSceneCode.GDpairsObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDpairsObjects4[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDpairsObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDpairsObjects4[i].getBehavior("Tween").addObjectColorTween("flash", "179;211;48", "easeInOutQuad", 250, false);
}
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x6b7a2c(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.NewSceneCode.GDcard_95anemoneObjects4.createFrom(runtimeScene.getObjects("card_anemone"));
gdjs.NewSceneCode.GDcard_95blowfishObjects4.createFrom(runtimeScene.getObjects("card_blowfish"));
gdjs.NewSceneCode.GDcard_95coralObjects4.createFrom(runtimeScene.getObjects("card_coral"));
gdjs.NewSceneCode.GDcard_95crabObjects4.createFrom(runtimeScene.getObjects("card_crab"));
gdjs.NewSceneCode.GDcard_95plasticbagObjects4.createFrom(runtimeScene.getObjects("card_plasticbag"));
gdjs.NewSceneCode.GDcard_95seagrassObjects4.createFrom(runtimeScene.getObjects("card_seagrass"));
gdjs.NewSceneCode.GDcard_95seahorseObjects4.createFrom(runtimeScene.getObjects("card_seahorse"));
gdjs.NewSceneCode.GDcard_95snailObjects4.createFrom(runtimeScene.getObjects("card_snail"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95blowfishObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95blowfishObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95blowfishObjects4[k] = gdjs.NewSceneCode.GDcard_95blowfishObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95blowfishObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95crabObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95crabObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95crabObjects4[k] = gdjs.NewSceneCode.GDcard_95crabObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95crabObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seahorseObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seahorseObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seahorseObjects4[k] = gdjs.NewSceneCode.GDcard_95seahorseObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seahorseObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95snailObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95snailObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95snailObjects4[k] = gdjs.NewSceneCode.GDcard_95snailObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95snailObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seagrassObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seagrassObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seagrassObjects4[k] = gdjs.NewSceneCode.GDcard_95seagrassObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seagrassObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95coralObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95coralObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95coralObjects4[k] = gdjs.NewSceneCode.GDcard_95coralObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95coralObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95anemoneObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95anemoneObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95anemoneObjects4[k] = gdjs.NewSceneCode.GDcard_95anemoneObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95anemoneObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95plasticbagObjects4[k] = gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length = k;}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition1IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7135780);
}
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDcard_95anemoneObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95blowfishObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95coralObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95crabObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95plasticbagObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seagrassObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95seahorseObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95snailObjects4 */
{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
}}

}


{



}


{


{
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6b78ac
gdjs.NewSceneCode.eventsList0x6b76fc = function(runtimeScene) {

{


{

{ //Subevents
gdjs.NewSceneCode.eventsList0x6b78ac(runtimeScene);} //End of subevents
}

}


{


{
{runtimeScene.getVariables().getFromIndex(4).setString("player_turn");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6b76fc
gdjs.NewSceneCode.eventsList0x6ad734 = function(runtimeScene) {

{


{
/* Reuse gdjs.NewSceneCode.GDcard_95anemoneObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95blowfishObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95coralObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95crabObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95plasticbagObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95seagrassObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95seahorseObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95snailObjects1 */
{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects1[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95blowfishObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95blowfishObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95crabObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95crabObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seahorseObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seahorseObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95snailObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95snailObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95seagrassObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95seagrassObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95coralObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95coralObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95anemoneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95anemoneObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95plasticbagObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95plasticbagObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6ad734
gdjs.NewSceneCode.eventsList0x6da6a4 = function(runtimeScene) {

{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)) == "player_turn";
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList0x6da774(runtimeScene);} //End of subevents
}

}


{

gdjs.NewSceneCode.GDcard_95anemoneObjects2.createFrom(runtimeScene.getObjects("card_anemone"));
gdjs.NewSceneCode.GDcard_95blowfishObjects2.createFrom(runtimeScene.getObjects("card_blowfish"));
gdjs.NewSceneCode.GDcard_95coralObjects2.createFrom(runtimeScene.getObjects("card_coral"));
gdjs.NewSceneCode.GDcard_95crabObjects2.createFrom(runtimeScene.getObjects("card_crab"));
gdjs.NewSceneCode.GDcard_95plasticbagObjects2.createFrom(runtimeScene.getObjects("card_plasticbag"));
gdjs.NewSceneCode.GDcard_95seagrassObjects2.createFrom(runtimeScene.getObjects("card_seagrass"));
gdjs.NewSceneCode.GDcard_95seahorseObjects2.createFrom(runtimeScene.getObjects("card_seahorse"));
gdjs.NewSceneCode.GDcard_95snailObjects2.createFrom(runtimeScene.getObjects("card_snail"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95blowfishObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95blowfishObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95blowfishObjects2[k] = gdjs.NewSceneCode.GDcard_95blowfishObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95blowfishObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95crabObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95crabObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95crabObjects2[k] = gdjs.NewSceneCode.GDcard_95crabObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95crabObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seahorseObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seahorseObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seahorseObjects2[k] = gdjs.NewSceneCode.GDcard_95seahorseObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seahorseObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95snailObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95snailObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95snailObjects2[k] = gdjs.NewSceneCode.GDcard_95snailObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95snailObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seagrassObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seagrassObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seagrassObjects2[k] = gdjs.NewSceneCode.GDcard_95seagrassObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seagrassObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95coralObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95coralObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95coralObjects2[k] = gdjs.NewSceneCode.GDcard_95coralObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95coralObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95anemoneObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95anemoneObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95anemoneObjects2[k] = gdjs.NewSceneCode.GDcard_95anemoneObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95anemoneObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95plasticbagObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95plasticbagObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95plasticbagObjects2[k] = gdjs.NewSceneCode.GDcard_95plasticbagObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95plasticbagObjects2.length = k;}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList0x6b35bc(runtimeScene);} //End of subevents
}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.5, "show_cards");
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition1IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7043052);
}
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList0x6b76fc(runtimeScene);} //End of subevents
}

}


{

gdjs.NewSceneCode.GDcard_95anemoneObjects1.createFrom(runtimeScene.getObjects("card_anemone"));
gdjs.NewSceneCode.GDcard_95blowfishObjects1.createFrom(runtimeScene.getObjects("card_blowfish"));
gdjs.NewSceneCode.GDcard_95coralObjects1.createFrom(runtimeScene.getObjects("card_coral"));
gdjs.NewSceneCode.GDcard_95crabObjects1.createFrom(runtimeScene.getObjects("card_crab"));
gdjs.NewSceneCode.GDcard_95plasticbagObjects1.createFrom(runtimeScene.getObjects("card_plasticbag"));
gdjs.NewSceneCode.GDcard_95seagrassObjects1.createFrom(runtimeScene.getObjects("card_seagrass"));
gdjs.NewSceneCode.GDcard_95seahorseObjects1.createFrom(runtimeScene.getObjects("card_seahorse"));
gdjs.NewSceneCode.GDcard_95snailObjects1.createFrom(runtimeScene.getObjects("card_snail"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95blowfishObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95blowfishObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95blowfishObjects1[k] = gdjs.NewSceneCode.GDcard_95blowfishObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95blowfishObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95crabObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95crabObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95crabObjects1[k] = gdjs.NewSceneCode.GDcard_95crabObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95crabObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seahorseObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seahorseObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seahorseObjects1[k] = gdjs.NewSceneCode.GDcard_95seahorseObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seahorseObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95snailObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95snailObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95snailObjects1[k] = gdjs.NewSceneCode.GDcard_95snailObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95snailObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95seagrassObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95seagrassObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95seagrassObjects1[k] = gdjs.NewSceneCode.GDcard_95seagrassObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95seagrassObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95coralObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95coralObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95coralObjects1[k] = gdjs.NewSceneCode.GDcard_95coralObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95coralObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95anemoneObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95anemoneObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95anemoneObjects1[k] = gdjs.NewSceneCode.GDcard_95anemoneObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95anemoneObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95plasticbagObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95plasticbagObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95plasticbagObjects1[k] = gdjs.NewSceneCode.GDcard_95plasticbagObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95plasticbagObjects1.length = k;}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition1IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7002164);
}
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList0x6ad734(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6da6a4
gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDnewgame_9595buttonObjects2Objects = Hashtable.newFrom({"newgame_button": gdjs.NewSceneCode.GDnewgame_95buttonObjects2});gdjs.NewSceneCode.eventsList0x6b4924 = function(runtimeScene) {

{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition0IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7031772);
}
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDnewgame_95buttonObjects3.createFrom(gdjs.NewSceneCode.GDnewgame_95buttonObjects2);

{for(var i = 0, len = gdjs.NewSceneCode.GDnewgame_95buttonObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDnewgame_95buttonObjects3[i].getBehavior("Tween").addObjectColorTween("shine", "255;255;255", "easeFromTo", 500, false);
}
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/pop.ogg", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "NewScene", false);
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6b4924
gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDnewgame_9595buttonObjects1Objects = Hashtable.newFrom({"newgame_button": gdjs.NewSceneCode.GDnewgame_95buttonObjects1});gdjs.NewSceneCode.eventsList0x6b5064 = function(runtimeScene) {

{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition0IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7033604);
}
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDnewgame_95buttonObjects1 */
{for(var i = 0, len = gdjs.NewSceneCode.GDnewgame_95buttonObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDnewgame_95buttonObjects1[i].getBehavior("Tween").addObjectColorTween("shine", "200;200;200", "easeFromTo", 500, false);
}
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6b5064
gdjs.NewSceneCode.eventsList0x6cc20c = function(runtimeScene) {

{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition0IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7127948);
}
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDnewgameObjects2.createFrom(runtimeScene.getObjects("newgame"));
gdjs.NewSceneCode.GDnewgame_95buttonObjects2.createFrom(runtimeScene.getObjects("newgame_button"));
{for(var i = 0, len = gdjs.NewSceneCode.GDnewgame_95buttonObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDnewgame_95buttonObjects2[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDnewgame_95buttonObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDnewgame_95buttonObjects2[i].getBehavior("Tween").addObjectScaleTween("pop_up_button", 1, 1, "elastic", 1500, false);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDnewgameObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDnewgameObjects2[i].setScaleX(0.5);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDnewgameObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDnewgameObjects2[i].setScaleY(0.5);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDnewgameObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDnewgameObjects2[i].getBehavior("Tween").addObjectScaleTween("pop_up_button_text", 1, 1, "elastic", 1500, false);
}
}}

}


{



}


{

gdjs.NewSceneCode.GDnewgame_95buttonObjects2.createFrom(runtimeScene.getObjects("newgame_button"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDnewgame_9595buttonObjects2Objects, runtimeScene, true, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList0x6b4924(runtimeScene);} //End of subevents
}

}


{

gdjs.NewSceneCode.GDnewgame_95buttonObjects1.createFrom(runtimeScene.getObjects("newgame_button"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDnewgame_9595buttonObjects1Objects, runtimeScene, true, true);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList0x6b5064(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6cc20c
gdjs.NewSceneCode.eventsList0x6cbedc = function(runtimeScene) {

{



}


{


{
gdjs.NewSceneCode.GDpairsObjects2.createFrom(runtimeScene.getObjects("pairs"));
{for(var i = 0, len = gdjs.NewSceneCode.GDpairsObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDpairsObjects2[i].setString("Pairs: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)));
}
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "UI");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList0x6cc20c(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6cbedc
gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595blowfishObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595crabObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seahorseObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595snailObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seagrassObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595coralObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595anemoneObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595plasticbagObjects1Objects = Hashtable.newFrom({"card_blowfish": gdjs.NewSceneCode.GDcard_95blowfishObjects1, "card_crab": gdjs.NewSceneCode.GDcard_95crabObjects1, "card_seahorse": gdjs.NewSceneCode.GDcard_95seahorseObjects1, "card_snail": gdjs.NewSceneCode.GDcard_95snailObjects1, "card_seagrass": gdjs.NewSceneCode.GDcard_95seagrassObjects1, "card_coral": gdjs.NewSceneCode.GDcard_95coralObjects1, "card_anemone": gdjs.NewSceneCode.GDcard_95anemoneObjects1, "card_plasticbag": gdjs.NewSceneCode.GDcard_95plasticbagObjects1});gdjs.NewSceneCode.eventsList0x6ce4cc = function(runtimeScene) {

{



}


{


{
/* Reuse gdjs.NewSceneCode.GDui_95backgroundObjects1 */
{for(var i = 0, len = gdjs.NewSceneCode.GDui_95backgroundObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDui_95backgroundObjects1[i].getBehavior("Tween").addObjectOpacityTween("fade_out", 175, "linear", 1000, false);
}
}}

}


}; //End of gdjs.NewSceneCode.eventsList0x6ce4cc
gdjs.NewSceneCode.eventsList0x6ce3fc = function(runtimeScene) {

{

gdjs.NewSceneCode.GDcard_95anemoneObjects1.createFrom(runtimeScene.getObjects("card_anemone"));
gdjs.NewSceneCode.GDcard_95blowfishObjects1.createFrom(runtimeScene.getObjects("card_blowfish"));
gdjs.NewSceneCode.GDcard_95coralObjects1.createFrom(runtimeScene.getObjects("card_coral"));
gdjs.NewSceneCode.GDcard_95crabObjects1.createFrom(runtimeScene.getObjects("card_crab"));
gdjs.NewSceneCode.GDcard_95plasticbagObjects1.createFrom(runtimeScene.getObjects("card_plasticbag"));
gdjs.NewSceneCode.GDcard_95seagrassObjects1.createFrom(runtimeScene.getObjects("card_seagrass"));
gdjs.NewSceneCode.GDcard_95seahorseObjects1.createFrom(runtimeScene.getObjects("card_seahorse"));
gdjs.NewSceneCode.GDcard_95snailObjects1.createFrom(runtimeScene.getObjects("card_snail"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595blowfishObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595crabObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seahorseObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595snailObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595seagrassObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595coralObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595anemoneObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595plasticbagObjects1Objects) <= 0;
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition1IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7136676);
}
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
gdjs.NewSceneCode.GDui_95backgroundObjects1.createFrom(runtimeScene.getObjects("ui_background"));
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/Rise.ogg", false, 100, 1);
}{for(var i = 0, len = gdjs.NewSceneCode.GDui_95backgroundObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDui_95backgroundObjects1[i].setOpacity(0);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "UI");
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x6ce4cc(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6ce3fc
gdjs.NewSceneCode.eventsList0xb4be0 = function(runtimeScene) {

{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("Prepage the board"); }gdjs.NewSceneCode.eventsList0x6a34dc(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("Prepage the board"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("Cards logic"); }gdjs.NewSceneCode.eventsList0x6da6a4(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("Cards logic"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("GUI"); }gdjs.NewSceneCode.eventsList0x6cbedc(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("GUI"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("Check if game is won"); }gdjs.NewSceneCode.eventsList0x6ce3fc(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("Check if game is won"); }
}


}; //End of gdjs.NewSceneCode.eventsList0xb4be0


gdjs.NewSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.NewSceneCode.GDcard_95crabObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95crabObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95crabObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95crabObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95crabObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95crabObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95crabObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95seahorseObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95seahorseObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95seahorseObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95seahorseObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95seahorseObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95seahorseObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95seahorseObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95snailObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95snailObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95snailObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95snailObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95snailObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95snailObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95snailObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95seagrassObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95seagrassObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95seagrassObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95seagrassObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95seagrassObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95seagrassObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95seagrassObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95coralObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95coralObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95coralObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95coralObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95coralObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95coralObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95coralObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95anemoneObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95anemoneObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95anemoneObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95anemoneObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95anemoneObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95anemoneObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95anemoneObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95plasticbagObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95plasticbagObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95plasticbagObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95plasticbagObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95plasticbagObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95plasticbagObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95plasticbagObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95blowfishObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95blowfishObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95blowfishObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95blowfishObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95blowfishObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95blowfishObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95blowfishObjects7.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects1.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects2.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects3.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects4.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects5.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects6.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects7.length = 0;
gdjs.NewSceneCode.GDnewgame_95buttonObjects1.length = 0;
gdjs.NewSceneCode.GDnewgame_95buttonObjects2.length = 0;
gdjs.NewSceneCode.GDnewgame_95buttonObjects3.length = 0;
gdjs.NewSceneCode.GDnewgame_95buttonObjects4.length = 0;
gdjs.NewSceneCode.GDnewgame_95buttonObjects5.length = 0;
gdjs.NewSceneCode.GDnewgame_95buttonObjects6.length = 0;
gdjs.NewSceneCode.GDnewgame_95buttonObjects7.length = 0;
gdjs.NewSceneCode.GDboardObjects1.length = 0;
gdjs.NewSceneCode.GDboardObjects2.length = 0;
gdjs.NewSceneCode.GDboardObjects3.length = 0;
gdjs.NewSceneCode.GDboardObjects4.length = 0;
gdjs.NewSceneCode.GDboardObjects5.length = 0;
gdjs.NewSceneCode.GDboardObjects6.length = 0;
gdjs.NewSceneCode.GDboardObjects7.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects1.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects2.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects3.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects4.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects5.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects6.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects7.length = 0;
gdjs.NewSceneCode.GDpairsObjects1.length = 0;
gdjs.NewSceneCode.GDpairsObjects2.length = 0;
gdjs.NewSceneCode.GDpairsObjects3.length = 0;
gdjs.NewSceneCode.GDpairsObjects4.length = 0;
gdjs.NewSceneCode.GDpairsObjects5.length = 0;
gdjs.NewSceneCode.GDpairsObjects6.length = 0;
gdjs.NewSceneCode.GDpairsObjects7.length = 0;
gdjs.NewSceneCode.GDnewgameObjects1.length = 0;
gdjs.NewSceneCode.GDnewgameObjects2.length = 0;
gdjs.NewSceneCode.GDnewgameObjects3.length = 0;
gdjs.NewSceneCode.GDnewgameObjects4.length = 0;
gdjs.NewSceneCode.GDnewgameObjects5.length = 0;
gdjs.NewSceneCode.GDnewgameObjects6.length = 0;
gdjs.NewSceneCode.GDnewgameObjects7.length = 0;
gdjs.NewSceneCode.GDyouwonObjects1.length = 0;
gdjs.NewSceneCode.GDyouwonObjects2.length = 0;
gdjs.NewSceneCode.GDyouwonObjects3.length = 0;
gdjs.NewSceneCode.GDyouwonObjects4.length = 0;
gdjs.NewSceneCode.GDyouwonObjects5.length = 0;
gdjs.NewSceneCode.GDyouwonObjects6.length = 0;
gdjs.NewSceneCode.GDyouwonObjects7.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects1.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects2.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects3.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects4.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects5.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects6.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects7.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects1.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects2.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects3.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects4.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects5.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects6.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects7.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects1.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects2.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects3.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects4.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects5.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects6.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects7.length = 0;
gdjs.NewSceneCode.GDtitleTextObjects1.length = 0;
gdjs.NewSceneCode.GDtitleTextObjects2.length = 0;
gdjs.NewSceneCode.GDtitleTextObjects3.length = 0;
gdjs.NewSceneCode.GDtitleTextObjects4.length = 0;
gdjs.NewSceneCode.GDtitleTextObjects5.length = 0;
gdjs.NewSceneCode.GDtitleTextObjects6.length = 0;
gdjs.NewSceneCode.GDtitleTextObjects7.length = 0;

gdjs.NewSceneCode.eventsList0xb4be0(runtimeScene);
return;

}
gdjs['NewSceneCode'] = gdjs.NewSceneCode;
